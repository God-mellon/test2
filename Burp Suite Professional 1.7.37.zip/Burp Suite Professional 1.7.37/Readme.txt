Run "burp-loader-keygen.jar" and follow the instructions.
=================
